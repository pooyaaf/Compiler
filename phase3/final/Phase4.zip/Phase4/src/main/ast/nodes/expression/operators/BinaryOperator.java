package main.ast.nodes.expression.operators;

public enum BinaryOperator {
    eq, gt, lt, add, sub, mult, div, and, or, assign
}
