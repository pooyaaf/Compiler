package main.symbolTable.utils.graph.exceptions;

public class GraphDoesNotContainNodeException extends Exception {
}
