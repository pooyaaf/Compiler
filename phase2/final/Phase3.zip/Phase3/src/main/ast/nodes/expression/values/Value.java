package main.ast.nodes.expression.values;

import main.ast.nodes.expression.Expression;

public abstract class Value extends Expression {
}
