package main.ast.types.primitives;

import main.ast.types.Type;

public class BoolType extends Type {
    @Override
    public String toString() {
        return "BoolType";
    }
}
